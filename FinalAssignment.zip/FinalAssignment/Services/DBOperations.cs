﻿using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace FinalAssignment.Services
{
    public class DBOperations
    {
        public DataTable GetData(string query)
        {
            string strConnString = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString.ToString();
            using (SqlConnection con = new SqlConnection(strConnString))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = query;
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = con;
                        sda.SelectCommand = cmd;
                        using (DataSet ds = new DataSet())
                        {
                            DataTable dt = new DataTable();
                            sda.Fill(dt);
                            return dt;
                        }
                    }
                }
            }
        }
    }
}