﻿namespace FinalAssignment.Models
{
    public class Candidate
    {
        public int CandidateId { get; set; }
        public string CandidateFirstName { get; set; }
        public string CandidateLastName { get; set; }
        public int OrganizationId { get; set; }
        public string EmailAddress { get; set; }
    }
}