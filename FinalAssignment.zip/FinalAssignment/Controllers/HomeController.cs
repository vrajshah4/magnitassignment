﻿using FinalAssignment.Models;
using FinalAssignment.Services;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Data;
using System.Web.Mvc;

namespace FinalAssignment.Controllers
{
    public class HomeController : Controller
    {
        DBOperations dBOperations = new DBOperations();  
        public ActionResult Index()
        {
            DataTable dt = dBOperations.GetData("Select * from Candidate");
            List<Candidate> candidates = new List<Candidate>();
            candidates = JArray.FromObject(dt).ToObject<List<Candidate>>();
            return View(candidates);
        }

        [HttpGet]
        public JsonResult GetOrganizationDetailsbyCandidateId(int candidateId)
        {
            DataTable dt = dBOperations.GetData(string.Format("Select O.Name, O.Address from Organization AS O Inner Join Candidate AS C on O.OrganizationId = C.OrganizationId Where C.CandidateId = '{0}'", candidateId));
            
            Organization organization = new Organization();
            organization.Name = dt.Rows[0]["Name"].ToString();
            organization.Address = dt.Rows[0]["Address"].ToString();

            return Json(organization, JsonRequestBehavior.AllowGet);
        }
    }
}